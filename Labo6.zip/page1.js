function isDateValide(dayData, monthData, yearData) {
    if (!hasOnlyIntegerNumber(yearData) || !hasOnlyIntegerNumber(monthData) || !hasOnlyIntegerNumber(dayData)) {
        return false
    }

 

    if (!inInterval(parseInt(monthData), 1, 12)) {
        return false
    } else {
        switch (parseInt(monthData)) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                if (!inInterval(parseInt(dayData), 1, 31)) {
                    return false;
                }
                break
            case 4:
            case 6:
            case 9:
            case 11:
                if (!inInterval(parseInt(dayData), 1, 30)) {
                    return false;
                }
                break;
            case 2:
                if (parseInt(yearData) % 4 == 0 && (parseInt(yearData) % 100 != 0 || parseInt(yearData) % 400 == 0) ) {
                    if (!inInterval(parseInt(dayData), 1, 29)) {
                        return false;
                    }
                } else {
                    if (!inInterval(parseInt(dayData), 1, 28)) {
                        return false;
                    }
                }
                break;
        }
        return true;
    }
}